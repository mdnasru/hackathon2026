# CampusFix verification — Ghousia redesign

## Executed automated checks

- PASS: 12 tests; validation, duplicate submissions, filtering, legacy persistence, suggestion errors/timeouts, shared SQLite server records, R2 adapter photo persistence, independent request reads, configured coordinator rejection/authorization, required solved photo, stale updates, saved status history, additive/idempotent samples.
- SKIPPED: 1 opt-in HTTP integration test. The managed preview is isolated from the shell network. `CAMPUSFIX_TEST_URL` can run it against a reachable disposable development environment. Actual browser upload verification is recorded below.
- PASS: native JavaScript syntax lint, TypeScript `tsc --noEmit`, Vinext production build and `git diff --check`.
- Credential-pattern review is performed before committing; no runtime credentials are written to source.

## Executed in Chrome

- PASS: empty required fields show inline errors and focus the first field.
- PASS: issue submission with a real PNG fixture, resized JPEG preview, shared save and report details.
- PASS: refresh restores the submitted issue and photo from server storage.
- PASS: Open → In progress; resolution is blocked without a solved photo.
- PASS: solved photo plus coordinator note saves Resolved; refresh preserves all three timestamps, both photos and note.
- PASS: both stored images load successfully; enlarged solved-photo dialog opens and closes.
- PASS: samples loaded twice, preserving the submitted report and producing exactly four fictional samples.
- PASS: combined library search + Water category + Resolved status returns the correct report.
- PASS: separate fresh UI load shows the same server records.
- PASS: 390px-wide frame (375px usable after scrollbar) shows responsive board and bottom navigation, measures equal content/viewport widths and completes a manual report without a photo or AI service.

## Limits of verification

- No physical phone or screen-reader audit was performed. Responsive checks used a browser frame.
- Coordinator allowlisting was tested in server-handler tests. No real college coordinator identities are configured on the live Site.
- Private deployment success must be verified through Sites status; its sign-in gate may block unsigned browser inspection. Local and hosted databases are separate.
- Unreliable-network upload behavior was not manually simulated.

## Repeatable manual checklist

1. Report an issue with title, description, precise campus location, category and optional photo.
2. Open its direct report link after refresh and in another authorized browser.
3. Search and filter; clear filters to see every report.
4. Start work, add a solved photo and resolution note, then resolve.
5. Confirm before/after evidence and timeline after refresh.
6. Repeat at phone width with keyboard navigation and reduced-motion preference.
7. Load fictional samples twice and verify user reports remain unchanged.
8. Before campus rollout, configure coordinator emails and explicitly approve the student audience.
