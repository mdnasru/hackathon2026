import {categories} from './domain.js';
export function ruleSuggestion(description) {
 const rules=[['Water',/water|tap|leak|pipe|drip|toilet|drain/i],['Electricity',/light|electric|power|socket|fan|wire/i],['Cleanliness',/bin|trash|rubbish|dirty|clean|waste|garbage/i],['Infrastructure',/stair|door|window|wall|chair|desk|rail|crack|road/i]];
 return {category:rules.find(([,re])=>re.test(description))?.[0]||'Other',summary:description.trim().split(/[.!?\n]/)[0].slice(0,120)};
}
export async function suggest(description,{provider=async text=>ruleSuggestion(text),timeout=5000}={}) {
 if(!description.trim()) throw Error('Add a description first.');
 let timer;
 try {const result=await Promise.race([provider(description),new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Suggestions timed out. You can still report manually.')),timeout);})]);
 if(!result||!categories.includes(result.category)||typeof result.summary!=='string'||!result.summary.trim()||result.summary.length>120) throw Error('Invalid suggestion. Please continue manually.');
 return result;
 }finally {clearTimeout(timer);}
}
