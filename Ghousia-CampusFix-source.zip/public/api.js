/** Shared persistence adapter. UI components never access the database directly. */
export async function request(path, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  try {
    const response = await fetch(path, { ...options, signal: controller.signal, cache: 'no-store' });
    const data = await response.json().catch(() => { throw Error('The server returned an unexpected response. Please retry.'); });
    if (!response.ok) throw Object.assign(Error(data.error || 'Something went wrong. Please retry.'), {fields:data.errors});
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw Error('The request timed out. Your form is still here; retrying will not duplicate your report.');
    throw error;
  } finally { clearTimeout(timer); }
}
export const repository = {
  load: () => request('/api/reports'),
  create: data => request('/api/reports', {method:'POST',body:data}),
  update: (id,data) => request('/api/reports/'+encodeURIComponent(id), {method:'PATCH',body:data}),
  samples: () => request('/api/samples', {method:'POST'}),
};
