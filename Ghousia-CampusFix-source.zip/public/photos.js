/** Resize locally and re-encode to remove embedded metadata before uploading. */
export async function preparePhoto(file) {
  if (!file) return null;
  if (!['image/jpeg','image/png','image/webp'].includes(file.type)) throw Error('Choose a JPG, PNG or WebP photo.');
  if (file.size > 10*1024*1024) throw Error('Choose a photo smaller than 10 MB.');
  const bitmap = await createImageBitmap(file).catch(() => {throw Error('This image could not be opened. Try another JPG or PNG.');});
  try {
    const scale = Math.min(1, 1600/Math.max(bitmap.width, bitmap.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(bitmap.width*scale)); canvas.height = Math.max(1,Math.round(bitmap.height*scale));
    const ctx = canvas.getContext('2d');
    ctx.fillStyle='#fff'; ctx.fillRect(0,0,canvas.width,canvas.height); ctx.drawImage(bitmap,0,0,canvas.width,canvas.height);
    const blob = await new Promise(resolve => canvas.toBlob(resolve,'image/jpeg',.85));
    if (!blob || blob.size > 5*1024*1024) throw Error('The photo could not be prepared. Choose a smaller image.');
    return new File([blob],'campus-location.jpg',{type:'image/jpeg'});
  } finally { bitmap.close(); }
}
