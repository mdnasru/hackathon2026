import {categories,statuses,validate} from './domain.js';
const KEY='campusfix.reports.v1';
function valid(r) {
 return r && typeof r.id==='string' && r.id.length<100 && typeof r.sample==='boolean' && !Object.keys(validate(r)).length && categories.includes(r.category) && statuses.includes(r.status) && Number.isFinite(Date.parse(r.createdAt)) && Array.isArray(r.history) && r.history.length>=1 && r.history.length<=3 && r.history.every((h,i)=>h.status===statuses[i] && Number.isFinite(Date.parse(h.at))) && r.history.at(-1).status===r.status;
}
export function createStorage(getStorage=()=>localStorage) {
 let blocked=false;
 return {
 load() {
  try {const raw=getStorage().getItem(KEY); if(raw===null) return {reports:[],error:''}; const data=JSON.parse(raw); if(data.version!==1||!Array.isArray(data.reports)||!data.reports.every(valid)||new Set(data.reports.map(r=>r.id)).size!==data.reports.length) throw Error('Invalid data'); return {reports:data.reports,error:''};}
  catch {blocked=true; return {reports:[],error:'Saved reports could not be read. Your existing data has been left untouched. Reporting is paused; try another browser or confirm a reset in Data settings.'};}
 },
 save(reports) {if(blocked) throw Error('Storage needs attention. Open Data settings to recover.'); try {getStorage().setItem(KEY,JSON.stringify({version:1,reports}));}catch {throw Error('This browser could not save your report. Free some storage or allow site storage, then try again. Your form is still here.');}},
 reset(){try {getStorage().removeItem(KEY);blocked=false;}catch {throw Error('Browser storage is unavailable. Enable site storage and try again.');}}
 };
}
