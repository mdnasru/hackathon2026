export const categories = ['Water','Electricity','Cleanliness','Infrastructure','Other'];
export const statuses = ['Open','In progress','Resolved'];
export function validate(input) {
 const errors = {};
 for (const [key,max] of Object.entries({title:120,description:3000,location:160})) {
  if (!input[key]?.trim()) errors[key] = `Please enter ${key === 'location' ? 'a campus location' : 'a '+key}.`;
  else if (input[key].trim().length > max) errors[key] = `Keep this under ${max} characters.`;
 }
 if (!categories.includes(input.category)) errors.category='Choose a category.';
 return errors;
}
export function createReport(input, reports, now = new Date().toISOString()) {
 if (Object.keys(validate(input)).length) throw new Error('Please check the highlighted fields.');
 const clean = Object.fromEntries(['title','description','location','category'].map(k=>[k,input[k].trim()]));
 const duplicate = reports.find(r=> !r.sample && ['title','description','location','category'].every(k=>r[k].toLowerCase()===clean[k].toLowerCase()));
 if (duplicate) return {report:duplicate,duplicate:true};
 return {report:{...clean,id:'CF-'+(crypto.randomUUID ? crypto.randomUUID() : Array.from(crypto.getRandomValues(new Uint8Array(16)), b=>b.toString(16).padStart(2,'0')).join('')).toUpperCase(),createdAt:now,status:'Open',sample:false,history:[{status:'Open',at:now}]},duplicate:false};
}
export function advance(report, now = new Date().toISOString()) {
 const status = statuses[statuses.indexOf(report.status)+1];
 if (!status) return report;
 return {...report,status,history:[...report.history,{status,at:now}]};
}
export function filterReports(reports,{query='',category='',status=''}={}) {
 const q=query.trim().toLowerCase();
 return reports.filter(r=>(!category||r.category===category)&&(!status||r.status===status)&&[r.title,r.description,r.location,r.id].some(t=>t.toLowerCase().includes(q))).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));
}
export function samples(now=Date.now()) {
 return [
 ['Leaking tap near the library','Water','Central Library · Ground floor','The drinking water tap beside the reading room keeps dripping. Water is collecting on the floor.','Open'],
 ['Lights flickering in the study room','Electricity','Academic Block B · Room 204','Two overhead lights flicker throughout the evening study session.','In progress'],
 ['Overflowing bins by the canteen','Cleanliness','Student Canteen · East entrance','The bins at the east entrance need emptying and the surrounding area needs cleaning.','Open'],
 ['Loose handrail on the north staircase','Infrastructure','Science Block · North stairs','The handrail between the first and second floor is loose at its lower bracket.','Resolved']
 ].map(([title,category,location,description,status],i)=>{const at=new Date(now-(i+1)*86400000).toISOString(); return {id:'CF-SAMPLE-'+(i+1),title,category,location,description,status,sample:true,createdAt:at,history:statuses.slice(0,statuses.indexOf(status)+1).map((s,j)=>({status:s,at:new Date(Date.parse(at)+j*3600000).toISOString()}))};});
}
