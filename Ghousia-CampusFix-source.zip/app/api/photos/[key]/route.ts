import { getPhoto } from '../../../../server/reports';
export async function GET(_request: Request, context: { params: Promise<{key: string}> }) {
  return getPhoto((await context.params).key);
}
