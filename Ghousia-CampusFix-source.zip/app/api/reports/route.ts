import { listReports, submitReport } from '../../../server/reports';
export const GET = listReports;
export const POST = submitReport;
