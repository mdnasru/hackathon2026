import { updateReport } from '../../../../server/reports';
export async function PATCH(request: Request, context: { params: Promise<{id: string}> }) {
  return updateReport(request, (await context.params).id);
}
