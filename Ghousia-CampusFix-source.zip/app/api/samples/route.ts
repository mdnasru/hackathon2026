export { loadSamples as POST } from '../../../server/reports';
