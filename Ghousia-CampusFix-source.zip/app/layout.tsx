import type { Metadata } from 'next';
export const metadata: Metadata = { title: 'CampusFix · Ghousia College of Engineering', description: 'A shared campus maintenance board for Ghousia College of Engineering.' };
export default function Layout({children}: {children: React.ReactNode}) { return <html lang="en"><body>{children}</body></html>; }
