import { env } from 'cloudflare:workers';
import { createReport, advance, validate, samples } from '../public/domain.js';

const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
const json = (body: unknown, status = 200) => Response.json(body, {
  status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' },
});
const bindings = () => {
  if (!env.DB || !env.BUCKET) throw new Error('Shared campus storage is unavailable. Please try again shortly.');
  return { db: env.DB, bucket: env.BUCKET };
};
export function coordinator(request: Request) {
  const configured = (env as unknown as { COORDINATOR_EMAILS?: string }).COORDINATOR_EMAILS;
  const emails = (configured || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
  return { demo: emails.length === 0, allowed: emails.length === 0 || emails.includes((request.headers.get('oai-authenticated-user-email') || '').toLowerCase()) };
}
function writeAllowed(request: Request) {
  const origin = request.headers.get('origin');
  if (origin && new URL(origin).host !== new URL(request.url).host && new URL(origin).host !== request.headers.get('host')) {
    throw new Error('Please submit from the CampusFix website.');
  }
  if (Number(request.headers.get('content-length') || 0) > 6 * 1024 * 1024) throw new Error('The upload is too large. Choose a photo under 5 MB.');
}
async function storeImage(file: FormDataEntryValue | null) {
  if (!file || typeof file === 'string' || file.size === 0) return null;
  if (file.size > MAX_IMAGE_BYTES) throw new Error('Choose a photo under 5 MB.');
  const bytes = new Uint8Array(await file.arrayBuffer());
  const jpeg = bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff;
  const png = bytes[0] === 137 && bytes[1] === 80 && bytes[2] === 78 && bytes[3] === 71;
  const webp = String.fromCharCode(...bytes.slice(0, 4)) === 'RIFF' && String.fromCharCode(...bytes.slice(8, 12)) === 'WEBP';
  const mime = jpeg ? 'image/jpeg' : png ? 'image/png' : webp ? 'image/webp' : null;
  if (bytes.length < 24 || !mime || file.type !== mime) throw new Error('Please upload a valid JPG, PNG or WebP image.');
  const key = crypto.randomUUID();
  await bindings().bucket.put(key, bytes, { httpMetadata: { contentType: mime } });
  return '/api/photos/' + key;
}
async function removeImage(path: string | null) {
  if (path) await bindings().bucket.delete(path.split('/').at(-1)!);
}
export async function listReports(request: Request) {
  try {
    const { results } = await bindings().db.prepare('SELECT payload FROM campus_reports ORDER BY created_at DESC').all<{payload: string}>();
    return json({ reports: results.map(r => JSON.parse(r.payload)), coordinator: coordinator(request), storage: 'shared' });
  } catch { return json({ error: 'The campus board could not be loaded. Please retry; your saved reports are not deleted.' }, 503); }
}
export async function submitReport(request: Request) {
  let photo: string | null = null;
  try {
    writeAllowed(request);
    const form = await request.formData();
    const data = Object.fromEntries(['title', 'description', 'location', 'category'].map(k => [k, String(form.get(k) || '')]));
    const errors = validate(data);
    if (Object.keys(errors).length) return json({ error: 'Check the highlighted fields.', errors }, 400);
    const key = String(form.get('submissionKey') || '');
    if (!/^[a-f\d-]{36}$/i.test(key)) return json({ error: 'Please refresh the form and try again.' }, 400);
    const { db } = bindings();
    const normalized = JSON.stringify(Object.fromEntries(Object.entries(data).map(([k,v]) => [k,v.trim().toLowerCase()])));
    const fingerprint = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(normalized))), b => b.toString(16).padStart(2,'0')).join('');
    const existing = await db.prepare('SELECT payload FROM campus_reports WHERE submission_key = ? OR fingerprint = ?').bind(key, fingerprint).first<{payload: string}>();
    if (existing) return json({ report: JSON.parse(existing.payload), duplicate: true });
    photo = await storeImage(form.get('photo'));
    const { report } = createReport(data, []);
    const record = { ...report, photo, resolvedPhoto: null, resolutionNote: '' };
    try {
      await db.prepare('INSERT INTO campus_reports (id,payload,submission_key,fingerprint,created_at) VALUES (?,?,?,?,?)').bind(record.id,JSON.stringify(record),key,fingerprint,record.createdAt).run();
    } catch (error) {
      await removeImage(photo); photo = null;
      const concurrent = await db.prepare('SELECT payload FROM campus_reports WHERE submission_key = ? OR fingerprint = ?').bind(key,fingerprint).first<{payload: string}>();
      if (concurrent) return json({ report: JSON.parse(concurrent.payload), duplicate: true });
      throw error;
    }
    return json({ report: record, duplicate: false }, 201);
  } catch (error) {
    await removeImage(photo).catch(() => {});
    return json({ error: error instanceof Error ? error.message : 'Could not submit the report. Please retry.' }, 400);
  }
}
export async function updateReport(request: Request, id: string) {
  let uploaded: string | null = null;
  try {
    writeAllowed(request);
    if (!coordinator(request).allowed) return json({ error: 'Only a configured coordinator can update reports.' }, 403);
    const { db } = bindings();
    const row = await db.prepare('SELECT payload FROM campus_reports WHERE id = ?').bind(id).first<{payload: string}>();
    if (!row) return json({ error: 'Report not found.' }, 404);
    const current = JSON.parse(row.payload);
    const form = await request.formData();
    if (String(form.get('previousStatus')) !== current.status) return json({ error: 'This issue has changed. Refresh the board before updating it.' }, 409);
    if (current.status === 'Resolved') return json({ error: 'This report is already resolved.' }, 409);
    const note = String(form.get('note') || '').trim();
    if (note.length > 1000) return json({ error: 'Keep the resolution note under 1000 characters.' }, 400);
    if (current.status === 'In progress') {
      uploaded = await storeImage(form.get('photo'));
      if (!uploaded) return json({ error: 'Upload a solved-location photo before marking this report resolved.' }, 400);
    }
    const updated = { ...advance(current), resolvedPhoto: uploaded || current.resolvedPhoto, resolutionNote: note || current.resolutionNote };
    const result = await db.prepare('UPDATE campus_reports SET payload = ? WHERE id = ? AND payload = ?').bind(JSON.stringify(updated),id,row.payload).run();
    if (!result.meta.changes) { await removeImage(uploaded); return json({ error: 'Another coordinator updated this issue. Refresh and try again.' }, 409); }
    return json({ report: updated });
  } catch (error) {
    await removeImage(uploaded).catch(() => {});
    return json({ error: error instanceof Error ? error.message : 'Could not update this report.' }, 400);
  }
}
export async function loadSamples(request: Request) {
  try {
    writeAllowed(request);
    const records = samples().map(r => ({...r,photo:null,resolvedPhoto:null,resolutionNote:''}));
    const statements = records.map(r => bindings().db.prepare('INSERT OR IGNORE INTO campus_reports (id,payload,submission_key,fingerprint,created_at) VALUES (?,?,?,?,?)').bind(r.id,JSON.stringify(r),r.id,r.id,r.createdAt));
    await bindings().db.batch(statements);
    return json({ ok: true });
  } catch { return json({ error: 'Could not load sample reports.' }, 503); }
}
export async function getPhoto(key: string) {
  if (!/^[a-f\d-]{36}$/i.test(key)) return new Response('Not found', { status: 404 });
  const object = await bindings().bucket.get(key);
  if (!object) return new Response('Not found', { status: 404 });
  return new Response(object.body, { headers: { 'Content-Type': object.httpMetadata?.contentType || 'image/jpeg', 'Cache-Control': 'private, max-age=3600', 'X-Content-Type-Options': 'nosniff', 'Content-Security-Policy': "default-src 'none'" } });
}
