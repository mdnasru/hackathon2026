import { readdir } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
for (const folder of ['public','tests','legacy']) {
 for (const file of await readdir(folder)) if (file.endsWith('.js')) execFileSync(process.execPath,['--check',folder+'/'+file]);
}
console.log('CampusFix JavaScript syntax checks passed.');
