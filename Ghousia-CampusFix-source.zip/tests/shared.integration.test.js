import test from 'node:test';
import assert from 'node:assert/strict';
const base=process.env.CAMPUSFIX_TEST_URL;
const group=base?test:test.skip;
async function request(path,options){const response=await fetch(base+path,options);return {status:response.status,data:await response.json()};}
function form(input){const f=new FormData();for(const[k,v]of Object.entries(input))f.set(k,v);return f;}
group('shared API: photo evidence, idempotency, validation, status history and cross-session reads',async()=>{
 const initial=await request('/api/reports');assert.equal(initial.status,200);assert.equal(initial.data.storage,'shared');
 const invalid=await request('/api/reports',{method:'POST',body:form({title:' ',description:' ',location:' ',category:'Water',submissionKey:crypto.randomUUID()})});assert.equal(invalid.status,400);assert.ok(invalid.data.errors.title);
 const key=crypto.randomUUID();const input={title:'Integration test '+key.slice(0,8),description:'Fictional test issue for verifying shared uploads.',location:'QA test location',category:'Infrastructure',submissionKey:key};
 const bad=form(input);bad.set('photo',new Blob(['not an image'],{type:'image/jpeg'}),'bad.jpg');assert.equal((await request('/api/reports',{method:'POST',body:bad})).status,400);
 const bytes=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jGv8AAAAASUVORK5CYII=','base64');
 const create=form(input);create.set('photo',new Blob([bytes],{type:'image/png'}),'fixture.png');
 const saved=await request('/api/reports',{method:'POST',body:create});assert.equal(saved.status,201);const report=saved.data.report;assert.match(report.photo,/api\/photos/);
 assert.equal((await fetch(base+report.photo)).status,200);
 const repeated=await request('/api/reports',{method:'POST',body:form(input)});assert.equal(repeated.data.report.id,report.id);assert.equal(repeated.data.duplicate,true);
 const independent=await request('/api/reports');assert.ok(independent.data.reports.some(r=>r.id===report.id));
 let result=await request('/api/reports/'+report.id,{method:'PATCH',body:form({previousStatus:'Open'})});assert.equal(result.data.report.status,'In progress');
 const stale=await request('/api/reports/'+report.id,{method:'PATCH',body:form({previousStatus:'Open'})});assert.equal(stale.status,409);
 const missing=await request('/api/reports/'+report.id,{method:'PATCH',body:form({previousStatus:'In progress'})});assert.equal(missing.status,400);assert.match(missing.data.error,/photo/);
 const solve=form({previousStatus:'In progress',note:'Fictional QA fix confirmed.'});solve.set('photo',new Blob([bytes],{type:'image/png'}),'solved.png');
 result=await request('/api/reports/'+report.id,{method:'PATCH',body:solve});assert.equal(result.data.report.status,'Resolved');assert.ok(result.data.report.resolvedPhoto);assert.equal(result.data.report.history.length,3);assert.equal(result.data.report.resolutionNote,'Fictional QA fix confirmed.');
 assert.equal((await fetch(base+result.data.report.resolvedPhoto)).status,200);
 const refresh=await request('/api/reports');assert.equal(refresh.data.reports.find(r=>r.id===report.id).status,'Resolved');
});
