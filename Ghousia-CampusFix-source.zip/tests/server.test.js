import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFile} from 'node:fs/promises';
import ts from 'typescript';

// Exercise the actual handlers with real SQLite SQL and an in-memory R2 adapter.
// The production module is transpiled only for this Node test environment.
const sqlite=new DatabaseSync(':memory:');
sqlite.exec(await readFile(new URL('../drizzle/0000_tricky_squadron_supreme.sql',import.meta.url),'utf8'));
const objects=new Map();
const db={
 prepare(sql){let values=[];return {
  bind(...args){values=args;return this;},
  async first(){return sqlite.prepare(sql).get(...values)||null;},
  async all(){return {results:sqlite.prepare(sql).all(...values)};},
  async run(){const result=sqlite.prepare(sql).run(...values);return {meta:{changes:Number(result.changes)}};},
 };},
 async batch(statements){sqlite.exec('BEGIN');try {const results=[];for(const s of statements)results.push(await s.run());sqlite.exec('COMMIT');return results;}catch(e){sqlite.exec('ROLLBACK');throw e;}},
};
const bucket={async put(key,bytes,options){objects.set(key,{body:bytes,httpMetadata:options.httpMetadata});},async get(key){return objects.get(key)||null;},async delete(key){objects.delete(key);}};
globalThis.__campusTestEnv={DB:db,BUCKET:bucket};
let source=await readFile(new URL('../server/reports.ts',import.meta.url),'utf8');
source=source.replace("import { env } from 'cloudflare:workers';","const env = globalThis.__campusTestEnv;").replace('../public/domain.js',new URL('../public/domain.js',import.meta.url).href);
const compiled=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}}).outputText;
const api=await import('data:text/javascript;base64,'+Buffer.from(compiled).toString('base64'));
const photo=()=>new Blob([Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jGv8AAAAASUVORK5CYII=','base64')],{type:'image/png'});
const form=values=>{const data=new FormData();for(const[k,v]of Object.entries(values))data.set(k,v);return data;};
const request=(body,method='POST',headers={})=>new Request('https://campus.test/api/reports',{method,headers,body});
let report;
test('shared server validates inputs, persists photo, deduplicates and allows independent reads',async()=>{
 let result=await api.submitReport(request(form({title:' ',description:' ',location:' ',category:'Water',submissionKey:crypto.randomUUID()})));assert.equal(result.status,400);assert.ok((await result.json()).errors.title);
 const values={title:'Tap leaking near library',description:'Fictional shared server test.',location:'Library ground floor',category:'Water',submissionKey:crypto.randomUUID()};
 const bad=form(values);bad.set('photo',new Blob(['invalid'],{type:'image/jpeg'}));assert.equal((await api.submitReport(request(bad))).status,400);
 const data=form(values);data.set('photo',photo(),'issue.png');result=await api.submitReport(request(data));assert.equal(result.status,201);report=(await result.json()).report;assert.ok(report.photo);assert.equal(objects.size,1);
 const repeated=await api.submitReport(request(form(values)));const duplicate=await repeated.json();assert.equal(duplicate.duplicate,true);assert.equal(duplicate.report.id,report.id);assert.equal(objects.size,1);
 const independent=await api.listReports(new Request('https://campus.test/api/reports'));assert.equal((await independent.json()).reports[0].id,report.id);
 assert.equal((await api.getPhoto(report.photo.split('/').at(-1))).status,200);
});
test('server enforces coordinator allowlist, sequential updates, required solved photo and durable history',async()=>{
 const env=globalThis.__campusTestEnv;env.COORDINATOR_EMAILS='coordinator@example.test';
 const denied=await api.updateReport(request(form({previousStatus:'Open'}),'PATCH'),report.id);assert.equal(denied.status,403);
 const trusted={'oai-authenticated-user-email':'coordinator@example.test'};
 let result=await api.updateReport(request(form({previousStatus:'Open'}),'PATCH',trusted),report.id);assert.equal((await result.json()).report.status,'In progress');
 const stale=await api.updateReport(request(form({previousStatus:'Open'}),'PATCH',trusted),report.id);assert.equal(stale.status,409);
 const missing=await api.updateReport(request(form({previousStatus:'In progress'}),'PATCH',trusted),report.id);assert.equal(missing.status,400);
 const data=form({previousStatus:'In progress',note:'Washer replaced; fictional test.'});data.set('photo',photo(),'solved.png');result=await api.updateReport(request(data,'PATCH',trusted),report.id);const solved=(await result.json()).report;
 assert.equal(solved.status,'Resolved');assert.ok(solved.resolvedPhoto);assert.equal(solved.history.length,3);assert.equal(solved.resolutionNote,'Washer replaced; fictional test.');assert.equal(objects.size,2);
 const persisted=(await (await api.listReports(new Request('https://campus.test/api/reports'))).json()).reports[0];assert.deepEqual(persisted,solved);
 delete env.COORDINATOR_EMAILS;
});
test('samples are additive and repeat loading does not overwrite the original report',async()=>{
 await api.loadSamples(request(form({})));await api.loadSamples(request(form({})));
 const list=await(await api.listReports(new Request('https://campus.test/api/reports'))).json();assert.equal(list.reports.length,5);assert.equal(list.reports.filter(r=>r.sample).length,4);assert.equal(list.reports.find(r=>r.id===report.id).status,'Resolved');
});
