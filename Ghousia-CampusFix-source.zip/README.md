# hackathon2026 — CampusFix for Ghousia College of Engineering

A mobile-friendly, shared campus maintenance board with issue photos, coordinator progress, solved-location photos, and timestamped history.

## What changed

The original browser-only prototype is preserved in Git history. This version keeps its native JavaScript UI and reporting rules, with a Vinext/Cloudflare server for shared D1 records and R2 photos. It no longer uses localStorage for new reports. Existing browser-only reports are not deleted or silently uploaded.

The UI includes an animated campus illustration, navy/teal/lime palette, a desktop sidebar, mobile bottom navigation, searchable report cards, status tabs, category filters, accessible form labels, visible keyboard focus and reduced-motion support. The artwork is illustrative and is not an actual photograph or official college logo.

## Features

- Shared reports across browsers and devices with access to the same deployed site.
- Title, description, campus location, category, optional issue photo and inline validation.
- Server-side duplicate prevention using a unique normalized report fingerprint and submission key.
- Server-validated Open → In progress → Resolved transitions. A solved-location photo is required for a real report to be resolved through the coordinator workflow.
- Before/after evidence, full-size photo viewer and optional resolution note.
- Optional rule-based category/title suggestions; descriptions are preserved.
- Fictional sample reports, explicitly labelled, added without replacing existing submissions.
- No automatic email, campus dispatch, maps, chat or payment services.

## Local setup

Use Node.js >=22.13.0 and pnpm (the locked version is declared in package.json).

```sh
pnpm install --frozen-lockfile
pnpm build
node --import ./scripts/sites-env.mjs ./node_modules/wrangler/bin/wrangler.js d1 execute DB --local --config dist/server/wrangler.json --persist-to .wrangler/state --file drizzle/0000_tricky_squadron_supreme.sql
pnpm dev
```

Open the URL printed by the dev server (normally http://localhost:5173). The migration above creates the local schema once; do not replay already-applied migrations. D1/R2 are simulated locally; no external API key is required. Local and deployed data are separate. Sites publishing provisions and binds hosted D1/R2 and applies the committed schema migration. `.openai/hosting.json` retains the existing Site identity.

```sh
pnpm test
pnpm lint
pnpm exec tsc --noEmit
pnpm build
```

`lint` checks native JavaScript syntax; it is not a full style linter. Integration tests are opt-in:

```sh
CAMPUSFIX_TEST_URL=http://localhost:5173 pnpm test
```

Run integration tests against a disposable test database: they create clearly labelled fictional QA reports and do not delete data. Without the URL, the integration test is explicitly skipped. The managed preview is isolated from the shell network; its end-to-end photo workflow was tested through browser controls instead.

## Shared data and photo storage

`public/api.js` separates UI from persistence. `server/reports.ts` implements the same-origin API. D1 stores each report and its history; R2 stores photos under random server-generated IDs. Photo URLs are served by the same site and inherit its access gate. Writes use optimistic concurrency checks to reject stale status updates. Samples use stable IDs and INSERT OR IGNORE.

Issue photos are optional. Solved photos are mandatory when moving In progress to Resolved. Choose JPG, PNG or WebP files up to 10 MB; the browser resizes to at most 1600 pixels and re-encodes JPEG before uploading, removing embedded metadata. The server limits accepted uploads to 5 MB, checks format signatures, and refuses SVG/executable formats. Users should photograph the issue rather than faces, documents or personal information.

The board fetches shared data on load and through Refresh. It is not a live push service. The board returns all reports; add pagination and indexed search before a larger rollout. There is no destructive shared-data reset control. Server/database backups and retention policies need campus approval before production use.

## Coordinator access

**By default, coordinator access is a clearly labelled demo.** All people who can access the site can update a report. A coordinator tab alone is not security.

To enforce coordinator roles, set server runtime variable `COORDINATOR_EMAILS` to a comma-separated list of approved college coordinators' actual ChatGPT sign-in email addresses. The server checks the trusted, dispatch-injected `oai-authenticated-user-email` header on every update, and the client receives only permission booleans. Do not trust a browser-provided role. The hosting access policy must be configured for the intended campus audience. No coordinator accounts, addresses or college integration are invented or preconfigured.

The existing private Site audience is preserved. Shared storage does not automatically grant all students permission to open a private Site. Public or campus-wide access should be explicitly chosen before rollout.

## AI

No real AI API is connected and no credentials are embedded. Suggestions are an explicitly labelled keyword-based demo. `public/suggestions.js` validates responses and handles errors and timeouts. Manual reporting always works. A real AI provider would require an authenticated, rate-limited server endpoint and a secret stored only in the server environment.

## Source structure

- `ui/index.html`: application shell served by `app/route.ts`
- `public/app.js`, `styles.css`, `icons.js`, `campus.svg`: UI, responsive styling, animation and artwork
- `public/domain.js`, `suggestions.js`: existing validation/filtering and optional assistance
- `public/api.js`, `photos.js`: shared persistence adapter and photo preparation
- `server/reports.ts`, `app/api/`: server validation, records, transitions and media
- `db/schema.ts`, `drizzle/`: schema and immutable migration
- `legacy/`: preserved browser-storage adapter for existing behavior tests, not used by the new UI
- `TEST_CHECKLIST.md`, `DEMO.md`: verification results and two-minute demo

## Limits

This is a working prototype, not a college-operated maintenance service. Default coordinator mode remains unrestricted demo mode, and the current hosting audience remains private. It needs approved coordinator accounts, an audience policy, moderation/rate limiting, retention/backups, and operational ownership for a campus-wide production launch. Real-world repairs must be confirmed by staff; a photo upload is evidence, not automated verification of workmanship.

GitHub reads worked in the original session, but branch creation returned 403 and direct push lacked credentials. Updated source is committed locally on `feat/ghousia-campusfix` and synchronized to the existing Site's source repository. Do not infer a GitHub PR was opened.
