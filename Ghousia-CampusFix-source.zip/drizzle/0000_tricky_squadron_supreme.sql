CREATE TABLE `campus_reports` (
	`id` text PRIMARY KEY NOT NULL,
	`payload` text NOT NULL,
	`submission_key` text NOT NULL,
	`fingerprint` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `campus_reports_submission_key_unique` ON `campus_reports` (`submission_key`);--> statement-breakpoint
CREATE UNIQUE INDEX `campus_reports_fingerprint_unique` ON `campus_reports` (`fingerprint`);