import { sqliteTable, text } from 'drizzle-orm/sqlite-core';

export const campusReports = sqliteTable('campus_reports', {
  id: text('id').primaryKey(),
  payload: text('payload').notNull(),
  submissionKey: text('submission_key').notNull().unique(),
  fingerprint: text('fingerprint').notNull().unique(),
  createdAt: text('created_at').notNull(),
});
