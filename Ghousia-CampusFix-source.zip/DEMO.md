# CampusFix — two-minute demonstration

**0:00–0:20 · A shared campus space**
“Ghousia College of Engineering students need one clear way to report campus problems. CampusFix puts every submitted issue, its photos and its progress on a shared board.” Show the animated overview, accurate counts and mobile navigation.

**0:20–0:55 · Report with a photo**
Open Report an issue. Enter a leaking tap example, description, precise location and Water category. Choose a location photo and show its preview. “Photos are optional for students. The writing helper is a labelled rule-based demo; no real AI API is connected.” Submit. Point out the unique report ID and saved description.

**0:55–1:15 · Everyone follows progress**
Refresh and return to the campus board. Search “tap” and filter Water/Open. “The records and images are now shared server data, not browser-only storage. Everyone with site access sees the same board.” Open the report and show the timeline.

**1:15–1:45 · Show the fix**
Point out the demo coordinator label. “Coordinators are unrestricted in the demo; a real rollout needs configured staff accounts.” Start work. Try resolving without an image to show the helpful requirement. Add a solved-location photo and a short note, then resolve. Show the before/after view and three timestamped stages.

**1:45–2:00 · Realistic next steps**
“The next step is for the college to approve coordinators, choose student access and appoint an operational owner. The hosting audience remains private for review; shared storage alone does not grant every student access. CampusFix tracks the work clearly, while actual repairs are carried out and confirmed by staff.”
